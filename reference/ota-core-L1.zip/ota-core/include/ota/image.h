#ifndef OTA_IMAGE_H
#define OTA_IMAGE_H

#include <stdint.h>
#include "ota/flash_layout.h"
#include "ota/ota_port.h"

#define IMAGE_MAGIC 0x4F544131u /* 'OTA1' */

/* Fixed 32 byte header at the start of every application slot.
   reserved[] is where the Ed25519 signature block will live in L3,
   which is why the struct is padded instead of 20 bytes. */
typedef struct {
    uint32_t magic;
    uint32_t version;
    uint32_t image_size;    /* payload bytes, header excluded */
    uint32_t payload_crc;   /* crc32 over payload               */
    uint32_t header_crc;    /* crc32 over the 20 bytes above    */
    uint8_t  reserved[IMAGE_HEADER_SIZE - 20u];
} image_header_t;

void image_header_finalize(image_header_t *h);
int  image_header_ok(const image_header_t *h);

/* 0 = slot holds a valid image, -1 = invalid.
   On success the header version and payload size are returned. */
int image_validate(flash_port_t flash, uint32_t slot_offset,
                   uint32_t *version, uint32_t *payload_size);

#endif /* OTA_IMAGE_H */
