#ifndef OTA_PORT_H
#define OTA_PORT_H

#include <stdint.h>
#include "ota/can_frame.h"

/* ------------------------------------------------------------------
 * Platform services required by the core.
 * ------------------------------------------------------------------
 * The core never touches registers, HAL or RTOS primitives. Every
 * hardware dependent operation goes through the two structs below:
 *
 *   host build  -> tests/bench.c (virtual bus + RAM flash)
 *   STM32 build -> src/port/stm32/ (CAN1 + FLASH driver), see README
 *
 * Return convention: 0 = success, negative = failure.
 */

typedef struct {
    int      (*can_send)(void *user, const can_frame_t *frame);
    uint32_t (*now_ms)(void *user);
    void     *user;
} ota_port_t;

/* Flash addresses are byte offsets from the start of internal flash
   (FLASH_BASE_ADDR, defined in flash_layout.h), not absolute addresses.
   This keeps the core unit-testable on a PC and avoids pointer types. */
typedef struct {
    int  (*erase)(void *user, uint32_t offset, uint32_t len);
    int  (*write)(void *user, uint32_t offset, const uint8_t *data, uint32_t len);
    int  (*read )(void *user, uint32_t offset, uint8_t *out, uint32_t len);
    void *user;
} flash_port_t;

#endif /* OTA_PORT_H */
