#ifndef OTA_BOOT_H
#define OTA_BOOT_H

#include "ota/metadata.h"

typedef enum {
    BOOT_TARGET_LOADER = 0,
    BOOT_TARGET_SLOT_A = 1,
    BOOT_TARGET_SLOT_B = 2
} boot_target_t;

/* Decides what to start. Side effects are intentional and part of the
   design: every call bumps boot_attempts, and after MAX_BOOT_ATTEMPTS
   without a confirmation the pending image is dropped (rollback).
   Call exactly once per reset, from the bootloader. */
boot_target_t boot_select(metadata_store_t *store, metadata_t *meta_out);

/* Called by the running application once it considers itself healthy:
   commits the pending slot as active and clears the attempt counter. */
int boot_confirm(metadata_store_t *store);

#endif /* OTA_BOOT_H */
