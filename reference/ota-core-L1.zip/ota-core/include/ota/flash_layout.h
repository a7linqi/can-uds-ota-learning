#ifndef OTA_FLASH_LAYOUT_H
#define OTA_FLASH_LAYOUT_H

/* ------------------------------------------------------------------
 * STM32F407VET6 internal flash, 512 KiB, sector aware.
 *
 * Sector map of the F4: s0..s3 = 16 KiB, s4 = 64 KiB, s5..s7 = 128 KiB.
 * The layout below is aligned to that structure so the same numbers can
 * be used with HAL_FLASHEx_Erase on the real target.
 *
 *   offset        size     use
 *   0x00000000    32 KiB   bootloader            (s0-s1)
 *   0x00008000    16 KiB   metadata slot A       (s2)
 *   0x0000C000    16 KiB   metadata slot B       (s3)
 *   0x00010000    64 KiB   reserved / vendor     (s4)
 *   0x00020000   128 KiB   application slot A    (s5)
 *   0x00040000   128 KiB   application slot B    (s6)
 *   0x00060000   128 KiB   unused                (s7)
 * ------------------------------------------------------------------ */

#define FLASH_BASE_ADDR   0x08000000u
#define FLASH_TOTAL_SIZE  0x00080000u

#define BOOT_OFFSET       0x00000000u
#define BOOT_SIZE         0x00008000u

#define META_A_OFFSET     0x00008000u
#define META_B_OFFSET     0x0000C000u
#define META_SIZE         0x00004000u

#define SPARE_OFFSET      0x00010000u
#define SPARE_SIZE        0x00010000u

#define SLOT_A_OFFSET     0x00020000u
#define SLOT_B_OFFSET     0x00040000u
#define SLOT_SIZE         0x00020000u
#define SLOT_COUNT        2u

#define SLOT_OFFSET(i)  (((i) == 0u) ? SLOT_A_OFFSET : SLOT_B_OFFSET)

/* Image = 32 byte header + payload. Payload must fit the slot. */
#define IMAGE_HEADER_SIZE 32u
#define IMAGE_MAX_PAYLOAD (SLOT_SIZE - IMAGE_HEADER_SIZE)

#endif /* OTA_FLASH_LAYOUT_H */
