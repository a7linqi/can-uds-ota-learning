#ifndef OTA_METADATA_H
#define OTA_METADATA_H

#include <stdint.h>
#include "ota/flash_layout.h"
#include "ota/ota_port.h"

#define META_MAGIC          0x4D455441u /* 'META' */
#define MAX_BOOT_ATTEMPTS   3u

/* Boot state record. Stored twice (slot A / slot B) and written
   alternately, so a power loss during the update of one copy always
   leaves the other copy intact. The record with the higher seq wins. */
typedef struct {
    uint32_t magic;
    uint32_t seq;              /* monotonically increasing          */
    uint32_t active_slot;      /* 0 = A, 1 = B                      */
    uint32_t pending_version;  /* 0 = no update pending             */
    uint32_t confirmed;        /* 1 = application reported healthy  */
    uint32_t boot_attempts;    /* tries of the pending image        */
    uint32_t crc;              /* crc32 over the 24 bytes above     */
} metadata_t;

typedef struct {
    flash_port_t flash;
    uint32_t slot_offsets[SLOT_COUNT];
} metadata_store_t;

void metadata_store_init(metadata_store_t *s, flash_port_t flash);

/* 1 = a valid record was found (highest seq), 0 = both slots blank.
   slot_index receives which physical copy was used. */
int metadata_load_ex(metadata_store_t *s, metadata_t *out, int *slot_index);
int metadata_load(metadata_store_t *s, metadata_t *out);

/* Writes the record to the other slot than the current one and
   bumps seq. Returns 0 on success. */
int metadata_save(metadata_store_t *s, metadata_t *m);

#endif /* OTA_METADATA_H */
