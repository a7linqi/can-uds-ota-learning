#ifndef BENCH_H
#define BENCH_H

#include "ota/isotp.h"
#include "ota/uds.h"
#include "flash_ram.h"

#define BENCH_REQ_MAX  2048u
#define BENCH_RESP_MAX 512u

typedef struct bench bench_t;

typedef struct {
    bench_t *b;
    uint8_t  self; /* 0 = tester, 1 = ecu */
} bench_node_t;

struct bench {
    flash_ram_t      flash;
    metadata_store_t meta;
    ota_port_t       ecu_port;
    ota_port_t       tester_port;
    isotp_link_t     ecu_link;
    isotp_link_t     tester_link;
    uds_server_t     server;
    bench_node_t     ecu_node;
    bench_node_t     tester_node;

    uint32_t now_ms;
    uint32_t frames;
    int      drop_fc; /* drop the next N flow control frames */
    int      drop_cf; /* drop the next N consecutive frames  */

    uint8_t  req_buf[BENCH_REQ_MAX];
    uint8_t  resp_buf[BENCH_RESP_MAX];
    uint8_t  tester_rx[BENCH_RESP_MAX];
    uint16_t tester_rx_len;
    int      resp_ready;
};

void bench_init(bench_t *b);
void bench_reset_links(bench_t *b);

/* Pumps both links until idle. 0 = ok, negative = transport error. */
int bench_run(bench_t *b);

/* Full UDS round trip: isotp send -> server -> isotp response.
   1 = response copied, 0 = no response, -1 = transport failure. */
int bench_request(bench_t *b, const uint8_t *req, uint16_t req_len,
                  uint8_t *resp, uint16_t *resp_len);

int bench_send_tester(bench_t *b, const uint8_t *data, uint16_t len);
int bench_read_ecu(bench_t *b, uint8_t *out, uint16_t out_max, uint16_t *out_len);
void bench_raw_to_ecu(bench_t *b, const can_frame_t *f);

#endif /* BENCH_H */
