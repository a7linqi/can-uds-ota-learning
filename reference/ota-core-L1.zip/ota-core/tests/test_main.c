#include <stdio.h>

#include "test_util.h"

int g_checks = 0;
int g_failures = 0;

void run_crc_tests(void);
void run_isotp_tests(void);
void run_uds_tests(void);
void run_boot_tests(void);

int main(void)
{
    printf("ota-core host tests\n");

    run_crc_tests();
    run_isotp_tests();
    run_uds_tests();
    run_boot_tests();

    printf("\n%d checks, %d failures\n", g_checks, g_failures);
    return g_failures == 0 ? 0 : 1;
}
