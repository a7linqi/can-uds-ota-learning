#include "bench.h"
#include "test_util.h"
#include "ota/boot.h"
#include "ota/image.h"
#include "ota/crc32.h"

#include <string.h>

static bench_t B;
static uint8_t img[8192];
static uint8_t payload[8192];
static uint8_t req[600];
static uint8_t resp[64];
static uint16_t rl;

static uint32_t build_image(uint32_t version, uint32_t len, int corrupt_payload, int bad_magic)
{
    image_header_t h;
    uint32_t i;
    uint32_t crc;

    for (i = 0u; i < len; i++) {
        payload[i] = (uint8_t)((i * 37u) ^ (version * 11u));
    }
    crc = crc32_calc(payload, len);
    if (corrupt_payload) {
        payload[len / 2u] ^= 0x5Au;
    }

    memset(&h, 0, sizeof h);
    h.magic = bad_magic ? 0x12345678u : IMAGE_MAGIC;
    h.version = version;
    h.image_size = len;
    h.payload_crc = crc;
    image_header_finalize(&h);

    memcpy(img, &h, sizeof h);
    memcpy(img + IMAGE_HEADER_SIZE, payload, len);
    return IMAGE_HEADER_SIZE + len;
}

static int unlock_programming(void)
{
    uint32_t seed;

    memset(req, 0, sizeof req);
    req[0] = 0x10;
    req[1] = 0x02;
    if (bench_request(&B, req, 2u, resp, &rl) != 1 || resp[0] != 0x50u) {
        return -1;
    }
    req[0] = 0x27;
    req[1] = 0x01;
    if (bench_request(&B, req, 2u, resp, &rl) != 1 || resp[0] != 0x67u) {
        return -1;
    }
    seed = t_get_be32(&resp[2]);
    req[0] = 0x27;
    req[1] = 0x02;
    t_put_be32(&req[2], uds_calc_key(seed));
    if (bench_request(&B, req, 6u, resp, &rl) != 1 || resp[0] != 0x67u) {
        return -1;
    }
    return 0;
}

static int start_download(uint32_t total, uint32_t addr)
{
    memset(req, 0, sizeof req);
    req[0] = 0x34u;
    req[1] = 0x00u;
    req[2] = 0x44u;
    t_put_be32(&req[3], addr);
    t_put_be32(&req[7], total);
    if (bench_request(&B, req, 11u, resp, &rl) != 1) {
        return -1;
    }
    return resp[0] == 0x74u ? 0 : (int)resp[2];
}

/* 0 = flashed and accepted, otherwise the NRC that stopped us. */
static int download(uint32_t total, uint32_t addr)
{
    uint32_t off = 0u;
    uint8_t counter = 1u;
    int r;

    if (unlock_programming() != 0) {
        return -100;
    }
    r = start_download(total, addr);
    if (r != 0) {
        return r;
    }

    while (off < total) {
        uint32_t left = total - off;
        uint16_t n = (uint16_t)(left > UDS_MAX_DOWNLOAD_BLOCK ? UDS_MAX_DOWNLOAD_BLOCK : left);
        req[0] = 0x36u;
        req[1] = counter;
        memcpy(&req[2], img + off, n);
        if (bench_request(&B, req, (uint16_t)(n + 2u), resp, &rl) != 1) {
            return -101;
        }
        if (resp[0] != 0x76u || resp[1] != counter) {
            return (int)resp[2];
        }
        off += n;
        counter++;
    }

    req[0] = 0x37u;
    if (bench_request(&B, req, 1u, resp, &rl) != 1) {
        return -102;
    }
    return resp[0] == 0x77u ? 0 : (int)resp[2];
}

void run_boot_tests(void)
{
    metadata_t m;
    uint32_t total;

    printf("[boot]\n");

    /* 1: blank device boots the loader */
    bench_init(&B);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_LOADER);

    /* 2: flash v2 into the inactive slot, boot picks it up as pending */
    total = build_image(2u, 1000u, 0, 0);
    TEST_ASSERT(download(total, FLASH_BASE_ADDR + SLOT_B_OFFSET) == 0);
    TEST_ASSERT(metadata_load(&B.meta, &m) == 1);
    TEST_ASSERT(m.pending_version == 2u);
    TEST_ASSERT(m.confirmed == 0u);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_B);
    TEST_ASSERT(m.boot_attempts == 1u);

    /* 3: app confirms -> B becomes the active slot */
    TEST_ASSERT(boot_confirm(&B.meta) == 0);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_B);
    TEST_ASSERT(m.active_slot == 1u);
    TEST_ASSERT(m.pending_version == 0u);

    /* 4: next update alternates into slot A */
    total = build_image(3u, 1000u, 0, 0);
    TEST_ASSERT(download(total, FLASH_BASE_ADDR + SLOT_A_OFFSET) == 0);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_A);
    TEST_ASSERT(boot_confirm(&B.meta) == 0);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_A);
    TEST_ASSERT(m.active_slot == 0u);

    /* 5: an interrupted download never becomes visible to the bootloader */
    total = build_image(4u, 1000u, 0, 0);
    TEST_ASSERT(unlock_programming() == 0);
    TEST_ASSERT(start_download(total, FLASH_BASE_ADDR + SLOT_B_OFFSET) == 0);
    req[0] = 0x36u;
    req[1] = 0x01u;
    memcpy(&req[2], img, 512u);
    TEST_ASSERT(bench_request(&B, req, 514u, resp, &rl) == 1);
    TEST_ASSERT(resp[0] == 0x76u);
    TEST_ASSERT(metadata_load(&B.meta, &m) == 1);
    TEST_ASSERT(m.pending_version == 0u);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_A);

    /* 6: payload corrupt -> 0x37 rejects, nothing pending */
    bench_init(&B);
    total = build_image(2u, 1000u, 1, 0);
    TEST_ASSERT(download(total, FLASH_BASE_ADDR + SLOT_B_OFFSET) == 0x72);
    TEST_ASSERT(metadata_load(&B.meta, &m) == 0);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_LOADER);

    /* 7: bad magic -> rejected */
    bench_init(&B);
    total = build_image(2u, 1000u, 0, 1);
    TEST_ASSERT(download(total, FLASH_BASE_ADDR + SLOT_B_OFFSET) == 0x72);

    /* 8: the active slot is not writable */
    bench_init(&B);
    total = build_image(2u, 1000u, 0, 0);
    TEST_ASSERT(unlock_programming() == 0);
    TEST_ASSERT(start_download(total, FLASH_BASE_ADDR + SLOT_A_OFFSET) == 0x31);
    TEST_ASSERT(start_download(total, 0x20000000u) == 0x31);

    /* 9: 0x34 while locked -> security denied */
    bench_init(&B);
    req[0] = 0x10u;
    req[1] = 0x02u;
    TEST_ASSERT(bench_request(&B, req, 2u, resp, &rl) == 1);
    TEST_ASSERT(start_download(total, FLASH_BASE_ADDR + SLOT_B_OFFSET) == 0x33);

    /* 10: three unconfirmed boots -> rollback to the previous image */
    bench_init(&B);
    total = build_image(1u, 1000u, 0, 0);
    TEST_ASSERT(download(total, FLASH_BASE_ADDR + SLOT_B_OFFSET) == 0);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_B);
    TEST_ASSERT(boot_confirm(&B.meta) == 0);

    total = build_image(2u, 1000u, 0, 0);
    TEST_ASSERT(download(total, FLASH_BASE_ADDR + SLOT_A_OFFSET) == 0);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_A);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_A);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_A);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_B);
    TEST_ASSERT(metadata_load(&B.meta, &m) == 1);
    TEST_ASSERT(m.pending_version == 0u);
    TEST_ASSERT(m.active_slot == 1u);

    /* 11: confirmation through UDS routine control 0x31 */
    bench_init(&B);
    total = build_image(2u, 1000u, 0, 0);
    TEST_ASSERT(download(total, FLASH_BASE_ADDR + SLOT_B_OFFSET) == 0);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_B);
    req[0] = 0x31u;
    req[1] = 0x01u;
    req[2] = 0x00u;
    req[3] = 0x01u;
    TEST_ASSERT(bench_request(&B, req, 4u, resp, &rl) == 1);
    TEST_ASSERT(resp[0] == 0x71u);
    TEST_ASSERT(boot_select(&B.meta, &m) == BOOT_TARGET_SLOT_B);
    TEST_ASSERT(m.active_slot == 1u);
    TEST_ASSERT(m.pending_version == 0u);
}
