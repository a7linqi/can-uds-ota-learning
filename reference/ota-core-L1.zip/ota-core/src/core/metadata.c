#include "ota/metadata.h"
#include "ota/crc32.h"

#include <string.h>

void metadata_store_init(metadata_store_t *s, flash_port_t flash)
{
    s->flash = flash;
    s->slot_offsets[0] = META_A_OFFSET;
    s->slot_offsets[1] = META_B_OFFSET;
}

static uint32_t meta_crc(const metadata_t *m)
{
    return crc32_calc((const uint8_t *)m, (uint32_t)((size_t)&m->crc - (size_t)m));
}

static int meta_read_copy(metadata_store_t *s, uint32_t which, metadata_t *out)
{
    if (s->flash.read == 0) {
        return -1;
    }
    if (s->flash.read(s->flash.user, s->slot_offsets[which], (uint8_t *)out, sizeof *out) != 0) {
        return -1;
    }
    if (out->magic != META_MAGIC) {
        return -1;
    }
    if (out->crc != meta_crc(out)) {
        return -1;
    }
    if (out->active_slot >= SLOT_COUNT) {
        return -1;
    }
    return 0;
}

int metadata_load_ex(metadata_store_t *s, metadata_t *out, int *slot_index)
{
    metadata_t a;
    metadata_t b;
    int have_a = (meta_read_copy(s, 0u, &a) == 0);
    int have_b = (meta_read_copy(s, 1u, &b) == 0);

    if (have_a && have_b) {
        if (a.seq >= b.seq) {
            *out = a;
            if (slot_index != 0) {
                *slot_index = 0;
            }
        } else {
            *out = b;
            if (slot_index != 0) {
                *slot_index = 1;
            }
        }
        return 1;
    }
    if (have_a) {
        *out = a;
        if (slot_index != 0) {
            *slot_index = 0;
        }
        return 1;
    }
    if (have_b) {
        *out = b;
        if (slot_index != 0) {
            *slot_index = 1;
        }
        return 1;
    }
    return 0;
}

int metadata_load(metadata_store_t *s, metadata_t *out)
{
    return metadata_load_ex(s, out, 0);
}

int metadata_save(metadata_store_t *s, metadata_t *m)
{
    metadata_t current;
    int current_slot = 0;
    int have = metadata_load_ex(s, &current, &current_slot);
    uint32_t target = have ? (uint32_t)(1 - current_slot) : 0u;
    uint32_t next_seq = have ? (current.seq + 1u) : 1u;

    if (s->flash.erase == 0 || s->flash.write == 0) {
        return -1;
    }

    m->magic = META_MAGIC;
    m->seq = next_seq;
    m->crc = 0u;
    m->crc = meta_crc(m);

    if (s->flash.erase(s->flash.user, s->slot_offsets[target], META_SIZE) != 0) {
        return -1;
    }
    if (s->flash.write(s->flash.user, s->slot_offsets[target], (const uint8_t *)m, sizeof *m) != 0) {
        return -1;
    }
    return 0;
}
