#include "ota/image.h"
#include "ota/crc32.h"

#include <string.h>

void image_header_finalize(image_header_t *h)
{
    h->header_crc = crc32_calc((const uint8_t *)h, (uint32_t)((size_t)&h->header_crc - (size_t)h));
}

int image_header_ok(const image_header_t *h)
{
    if (h->magic != IMAGE_MAGIC) {
        return 0;
    }
    if (h->image_size == 0u || h->image_size > IMAGE_MAX_PAYLOAD) {
        return 0;
    }
    return crc32_calc((const uint8_t *)h, (uint32_t)((size_t)&h->header_crc - (size_t)h)) == h->header_crc;
}

int image_validate(flash_port_t flash, uint32_t slot_offset,
                   uint32_t *version, uint32_t *payload_size)
{
    image_header_t h;
    uint8_t chunk[256];
    uint32_t crc = 0u;
    uint32_t off;
    uint32_t remaining;

    if (flash.read == 0) {
        return -1;
    }
    if (flash.read(flash.user, slot_offset, (uint8_t *)&h, sizeof h) != 0) {
        return -1;
    }
    if (!image_header_ok(&h)) {
        return -1;
    }
    if (slot_offset + IMAGE_HEADER_SIZE + h.image_size > FLASH_TOTAL_SIZE) {
        return -1;
    }

    off = slot_offset + IMAGE_HEADER_SIZE;
    remaining = h.image_size;
    while (remaining > 0u) {
        uint32_t n = remaining > sizeof chunk ? (uint32_t)sizeof chunk : remaining;
        if (flash.read(flash.user, off, chunk, n) != 0) {
            return -1;
        }
        crc = crc32_update(crc, chunk, n);
        off += n;
        remaining -= n;
    }
    if (crc != h.payload_crc) {
        return -1;
    }

    if (version != 0) {
        *version = h.version;
    }
    if (payload_size != 0) {
        *payload_size = h.image_size;
    }
    return 0;
}
