#include "ota/boot.h"
#include "ota/image.h"
#include "ota/flash_layout.h"

#include <string.h>

boot_target_t boot_select(metadata_store_t *store, metadata_t *meta_out)
{
    metadata_t m;
    uint32_t pending_slot;
    uint32_t version = 0u;
    uint32_t size = 0u;

    if (metadata_load(store, &m) != 1) {
        memset(&m, 0, sizeof m);
        m.active_slot = 0u;
        m.confirmed = 1u;
    }

    if (m.pending_version != 0u) {
        pending_slot = m.active_slot ^ 1u;

        if (image_validate(store->flash, SLOT_OFFSET(pending_slot), &version, &size) == 0
            && version == m.pending_version) {
            if (m.boot_attempts >= MAX_BOOT_ATTEMPTS) {
                /* The new image never reported healthy: roll back. */
                m.pending_version = 0u;
                m.boot_attempts = 0u;
                m.confirmed = 1u;
                (void)metadata_save(store, &m);
            } else {
                m.boot_attempts++;
                (void)metadata_save(store, &m);
                if (meta_out != 0) {
                    *meta_out = m;
                }
                return pending_slot == 0u ? BOOT_TARGET_SLOT_A : BOOT_TARGET_SLOT_B;
            }
        } else {
            /* Pending image is broken, drop it and keep the old one. */
            m.pending_version = 0u;
            m.boot_attempts = 0u;
            (void)metadata_save(store, &m);
        }
    }

    if (image_validate(store->flash, SLOT_OFFSET(m.active_slot), &version, &size) == 0) {
        if (meta_out != 0) {
            *meta_out = m;
        }
        return m.active_slot == 0u ? BOOT_TARGET_SLOT_A : BOOT_TARGET_SLOT_B;
    }

    if (meta_out != 0) {
        *meta_out = m;
    }
    return BOOT_TARGET_LOADER;
}

int boot_confirm(metadata_store_t *store)
{
    metadata_t m;

    if (metadata_load(store, &m) != 1) {
        return -1;
    }
    if (m.pending_version != 0u) {
        m.active_slot ^= 1u;
        m.pending_version = 0u;
    }
    m.confirmed = 1u;
    m.boot_attempts = 0u;
    return metadata_save(store, &m);
}
