#include "ota/uds.h"
#include "ota/boot.h"
#include "ota/flash_layout.h"
#include "ota/image.h"

#include <string.h>

/* ---- negative response codes (ISO 14229-1) ---- */
#define NRC_SERVICE_NOT_SUPPORTED       0x11u
#define NRC_SUBFUNCTION_NOT_SUPPORTED   0x12u
#define NRC_INCORRECT_LENGTH            0x13u
#define NRC_CONDITIONS_NOT_CORRECT      0x22u
#define NRC_REQUEST_SEQUENCE_ERROR      0x24u
#define NRC_REQUEST_OUT_OF_RANGE        0x31u
#define NRC_SECURITY_ACCESS_DENIED      0x33u
#define NRC_INVALID_KEY                 0x35u
#define NRC_EXCEEDED_ATTEMPTS           0x36u
#define NRC_GENERAL_PROGRAMMING_FAILURE 0x72u

static const uint8_t VIN_VALUE[]  = "LOTA0000000000001"; /* 17 chars */
static const uint8_t PART_VALUE[] = "OTA-ECU-0001";
static const uint8_t SW_VALUE[]   = "0.1.0";

static uint32_t get_be32(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16)
         | ((uint32_t)p[2] << 8)  | (uint32_t)p[3];
}

static void put_be32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}

static uint16_t nrc_reply(uint8_t *resp, uint16_t max, uint8_t sid, uint8_t code)
{
    if (max < 3u) {
        return 0u;
    }
    resp[0] = 0x7Fu;
    resp[1] = sid;
    resp[2] = code;
    return 3u;
}

static uint32_t server_now(uds_server_t *s)
{
    if (s->port != 0 && s->port->now_ms != 0) {
        return s->port->now_ms(s->port->user);
    }
    return 0u;
}

static uint8_t current_active_slot(uds_server_t *s)
{
    metadata_t m;

    if (s->store != 0 && metadata_load(s->store, &m) == 1) {
        return (uint8_t)m.active_slot;
    }
    return 0u;
}

uint32_t uds_calc_key(uint32_t seed)
{
    uint32_t k = seed ^ 0xA5A5A5A5u;

    k = (k << 7) | (k >> 25);
    k += 0x9E3779B9u;
    return k;
}

static int lockout_active(uds_server_t *s)
{
    uint32_t now;

    if (s->lockout_until_ms == 0u) {
        return 0;
    }
    now = server_now(s);
    if (now >= s->lockout_until_ms) {
        s->lockout_until_ms = 0u;
        s->key_failures = 0u;
        return 0;
    }
    return 1;
}

/* ---- 0x10 ---- */
static uint16_t handle_session(uds_server_t *s, const uint8_t *req, uint16_t req_len,
                               uint8_t *resp, uint16_t max)
{
    uint8_t sub;

    if (req_len < 2u) {
        return nrc_reply(resp, max, 0x10u, NRC_INCORRECT_LENGTH);
    }
    sub = (uint8_t)(req[1] & 0x7Fu);
    if (sub != UDS_SESSION_DEFAULT && sub != UDS_SESSION_PROGRAMMING && sub != UDS_SESSION_EXTENDED) {
        return nrc_reply(resp, max, 0x10u, NRC_SUBFUNCTION_NOT_SUPPORTED);
    }
    s->session = sub;
    s->unlocked = 0u;
    s->seed_valid = 0u;
    s->seed = 0u;
    s->dl_active = 0u;
    if ((req[1] & 0x80u) != 0u) {
        return 0u; /* positive response suppressed */
    }
    resp[0] = 0x50u;
    resp[1] = sub;
    resp[2] = 0x00u; /* P2   = 50 ms  */
    resp[3] = 0x32u;
    resp[4] = 0x13u; /* P2*  = 5000 ms */
    resp[5] = 0x88u;
    return 6u;
}

/* ---- 0x11 ---- */
static uint16_t handle_ecu_reset(uds_server_t *s, const uint8_t *req, uint16_t req_len,
                                 uint8_t *resp, uint16_t max)
{
    uint8_t sub;

    if (req_len < 2u) {
        return nrc_reply(resp, max, 0x11u, NRC_INCORRECT_LENGTH);
    }
    sub = (uint8_t)(req[1] & 0x7Fu);
    if (sub != 0x01u && sub != 0x03u) {
        return nrc_reply(resp, max, 0x11u, NRC_SUBFUNCTION_NOT_SUPPORTED);
    }
    s->reset_requested = 1u;
    if ((req[1] & 0x80u) != 0u) {
        return 0u;
    }
    resp[0] = 0x51u;
    resp[1] = sub;
    return 2u;
}

/* ---- 0x22 ---- */
static int append_did(uds_server_t *s, uint16_t did, uint8_t *resp, uint16_t *pos, uint16_t max)
{
    const uint8_t *data;
    uint16_t len;
    uint8_t session = s->session;

    switch (did) {
    case 0xF190u:
        data = VIN_VALUE;
        len = (uint16_t)(sizeof VIN_VALUE - 1u);
        break;
    case 0xF187u:
        data = PART_VALUE;
        len = (uint16_t)(sizeof PART_VALUE - 1u);
        break;
    case 0xF195u:
        data = SW_VALUE;
        len = (uint16_t)(sizeof SW_VALUE - 1u);
        break;
    case 0xF186u:
        data = &session;
        len = 1u;
        break;
    default:
        return -1;
    }
    if ((uint32_t)*pos + 2u + len > (uint32_t)max) {
        return -2;
    }
    resp[*pos] = (uint8_t)(did >> 8);
    (*pos)++;
    resp[*pos] = (uint8_t)(did & 0xFFu);
    (*pos)++;
    memcpy(&resp[*pos], data, len);
    *pos = (uint16_t)(*pos + len);
    return 0;
}

static uint16_t handle_read_data(uds_server_t *s, const uint8_t *req, uint16_t req_len,
                                 uint8_t *resp, uint16_t max)
{
    uint16_t count;
    uint16_t i;
    uint16_t pos = 1u;

    if (req_len < 3u || (uint16_t)((req_len - 1u) % 2u) != 0u) {
        return nrc_reply(resp, max, 0x22u, NRC_INCORRECT_LENGTH);
    }
    count = (uint16_t)((req_len - 1u) / 2u);
    resp[0] = 0x62u;
    for (i = 0u; i < count; i++) {
        uint16_t did = (uint16_t)((((uint16_t)req[1u + i * 2u]) << 8) | (uint16_t)req[2u + i * 2u]);
        int r = append_did(s, did, resp, &pos, max);
        if (r == -1) {
            return nrc_reply(resp, max, 0x22u, NRC_REQUEST_OUT_OF_RANGE);
        }
        if (r == -2) {
            return nrc_reply(resp, max, 0x22u, NRC_GENERAL_PROGRAMMING_FAILURE);
        }
    }
    return pos;
}

/* ---- 0x27 ---- */
static uint16_t handle_security(uds_server_t *s, const uint8_t *req, uint16_t req_len,
                                uint8_t *resp, uint16_t max)
{
    uint8_t sub;

    if (req_len < 2u) {
        return nrc_reply(resp, max, 0x27u, NRC_INCORRECT_LENGTH);
    }
    sub = req[1];
    if (lockout_active(s)) {
        return nrc_reply(resp, max, 0x27u, NRC_EXCEEDED_ATTEMPTS);
    }

    if (sub == 0x01u) { /* requestSeed */
        if (s->unlocked) {
            resp[0] = 0x67u;
            resp[1] = 0x01u;
            put_be32(&resp[2], 0u); /* already unlocked */
            return 6u;
        }
        s->request_count++;
        s->seed = 0xC0DE0000u ^ (s->request_count * 2654435761u);
        if (s->seed == 0u) {
            s->seed = 0x12345678u;
        }
        s->seed_valid = 1u;
        resp[0] = 0x67u;
        resp[1] = 0x01u;
        put_be32(&resp[2], s->seed);
        return 6u;
    }

    if (sub == 0x02u) { /* sendKey */
        uint32_t key;

        if (req_len < 6u) {
            return nrc_reply(resp, max, 0x27u, NRC_INCORRECT_LENGTH);
        }
        if (!s->seed_valid) {
            return nrc_reply(resp, max, 0x27u, NRC_REQUEST_SEQUENCE_ERROR);
        }
        key = get_be32(&req[2]);
        if (key != uds_calc_key(s->seed)) {
            s->seed_valid = 0u;
            s->key_failures++;
            if (s->key_failures >= 3u) {
                s->lockout_until_ms = server_now(s) + 10000u;
                if (s->lockout_until_ms == 0u) {
                    s->lockout_until_ms = 1u;
                }
                return nrc_reply(resp, max, 0x27u, NRC_EXCEEDED_ATTEMPTS);
            }
            return nrc_reply(resp, max, 0x27u, NRC_INVALID_KEY);
        }
        s->unlocked = 1u;
        s->seed_valid = 0u;
        s->seed = 0u;
        s->key_failures = 0u;
        resp[0] = 0x67u;
        resp[1] = 0x02u;
        return 2u;
    }

    return nrc_reply(resp, max, 0x27u, NRC_SUBFUNCTION_NOT_SUPPORTED);
}

/* ---- 0x34 ---- */
static uint16_t handle_request_download(uds_server_t *s, const uint8_t *req, uint16_t req_len,
                                        uint8_t *resp, uint16_t max)
{
    uint32_t addr;
    uint32_t size;
    uint8_t target;

    if (req_len < 11u) {
        return nrc_reply(resp, max, 0x34u, NRC_INCORRECT_LENGTH);
    }
    if (req[1] != 0x00u || req[2] != 0x44u) {
        return nrc_reply(resp, max, 0x34u, NRC_INCORRECT_LENGTH);
    }
    if (s->session != UDS_SESSION_PROGRAMMING) {
        return nrc_reply(resp, max, 0x34u, NRC_CONDITIONS_NOT_CORRECT);
    }
    if (!s->unlocked) {
        return nrc_reply(resp, max, 0x34u, NRC_SECURITY_ACCESS_DENIED);
    }
    if (s->dl_active) {
        return nrc_reply(resp, max, 0x34u, NRC_REQUEST_SEQUENCE_ERROR);
    }

    addr = get_be32(&req[3]);
    size = get_be32(&req[7]);
    target = current_active_slot(s) ^ 1u;

    /* Only the inactive slot is writable. This is the core protection:
       a bad or interrupted download can never touch the running image. */
    if (addr != FLASH_BASE_ADDR + SLOT_OFFSET(target)) {
        return nrc_reply(resp, max, 0x34u, NRC_REQUEST_OUT_OF_RANGE);
    }
    if (size < IMAGE_HEADER_SIZE || size > SLOT_SIZE) {
        return nrc_reply(resp, max, 0x34u, NRC_REQUEST_OUT_OF_RANGE);
    }
    if (s->flash.erase == 0 || s->flash.write == 0) {
        return nrc_reply(resp, max, 0x34u, NRC_GENERAL_PROGRAMMING_FAILURE);
    }
    if (s->flash.erase(s->flash.user, SLOT_OFFSET(target), SLOT_SIZE) != 0) {
        return nrc_reply(resp, max, 0x34u, NRC_GENERAL_PROGRAMMING_FAILURE);
    }

    s->dl_active = 1u;
    s->dl_slot = target;
    s->dl_offset = SLOT_OFFSET(target);
    s->dl_size = size;
    s->dl_written = 0u;
    s->dl_next_counter = 1u;

    if (max < 6u) {
        return 0u;
    }
    resp[0] = 0x74u;
    resp[1] = 0x20u; /* lengthFormatIdentifier: 4 byte max block length */
    put_be32(&resp[2], UDS_MAX_DOWNLOAD_BLOCK);
    return 6u;
}

/* ---- 0x36 ---- */
static uint16_t handle_transfer_data(uds_server_t *s, const uint8_t *req, uint16_t req_len,
                                     uint8_t *resp, uint16_t max)
{
    uint8_t counter;
    uint16_t n;

    if (req_len < 3u) {
        return nrc_reply(resp, max, 0x36u, NRC_INCORRECT_LENGTH);
    }
    if (s->session != UDS_SESSION_PROGRAMMING) {
        return nrc_reply(resp, max, 0x36u, NRC_CONDITIONS_NOT_CORRECT);
    }
    if (!s->unlocked) {
        return nrc_reply(resp, max, 0x36u, NRC_SECURITY_ACCESS_DENIED);
    }
    if (!s->dl_active) {
        return nrc_reply(resp, max, 0x36u, NRC_REQUEST_SEQUENCE_ERROR);
    }
    counter = req[1];
    if (counter != s->dl_next_counter) {
        return nrc_reply(resp, max, 0x36u, NRC_REQUEST_SEQUENCE_ERROR);
    }
    n = (uint16_t)(req_len - 2u);
    if (n > UDS_MAX_DOWNLOAD_BLOCK) {
        return nrc_reply(resp, max, 0x36u, NRC_INCORRECT_LENGTH);
    }
    if (s->dl_written + (uint32_t)n > s->dl_size) {
        return nrc_reply(resp, max, 0x36u, NRC_REQUEST_OUT_OF_RANGE);
    }
    if (s->flash.write(s->flash.user, s->dl_offset + s->dl_written, &req[2], n) != 0) {
        return nrc_reply(resp, max, 0x36u, NRC_GENERAL_PROGRAMMING_FAILURE);
    }
    s->dl_written += (uint32_t)n;
    s->dl_next_counter = (uint8_t)((counter + 1u) & 0xFFu);
    if (s->dl_next_counter == 0u) {
        s->dl_next_counter = 1u;
    }
    resp[0] = 0x76u;
    resp[1] = counter;
    return 2u;
}

/* ---- 0x37 ---- */
static uint16_t handle_transfer_exit(uds_server_t *s, const uint8_t *req, uint16_t req_len,
                                     uint8_t *resp, uint16_t max)
{
    metadata_t m;
    uint32_t version = 0u;
    uint32_t payload = 0u;

    (void)req;
    (void)req_len;

    if (s->session != UDS_SESSION_PROGRAMMING) {
        return nrc_reply(resp, max, 0x37u, NRC_CONDITIONS_NOT_CORRECT);
    }
    if (!s->unlocked) {
        return nrc_reply(resp, max, 0x37u, NRC_SECURITY_ACCESS_DENIED);
    }
    if (!s->dl_active) {
        return nrc_reply(resp, max, 0x37u, NRC_REQUEST_SEQUENCE_ERROR);
    }
    if (s->dl_written != s->dl_size) {
        return nrc_reply(resp, max, 0x37u, NRC_REQUEST_SEQUENCE_ERROR);
    }
    if (image_validate(s->flash, s->dl_offset, &version, &payload) != 0
        || payload + IMAGE_HEADER_SIZE != s->dl_size) {
        return nrc_reply(resp, max, 0x37u, NRC_GENERAL_PROGRAMMING_FAILURE);
    }

    if (metadata_load(s->store, &m) != 1) {
        memset(&m, 0, sizeof m);
        m.active_slot = 0u;
        m.confirmed = 1u;
    }
    m.pending_version = version;
    m.confirmed = 0u;
    m.boot_attempts = 0u;
    if (metadata_save(s->store, &m) != 0) {
        return nrc_reply(resp, max, 0x37u, NRC_GENERAL_PROGRAMMING_FAILURE);
    }
    s->dl_active = 0u;

    resp[0] = 0x77u;
    return 1u;
}

/* ---- 0x31 ---- */
static uint16_t handle_routine(uds_server_t *s, const uint8_t *req, uint16_t req_len,
                               uint8_t *resp, uint16_t max)
{
    uint16_t rid;

    if (req_len < 4u) {
        return nrc_reply(resp, max, 0x31u, NRC_INCORRECT_LENGTH);
    }
    if ((uint8_t)(req[1] & 0x7Fu) != 0x01u) { /* startRoutine only */
        return nrc_reply(resp, max, 0x31u, NRC_SUBFUNCTION_NOT_SUPPORTED);
    }
    rid = (uint16_t)((((uint16_t)req[2]) << 8) | (uint16_t)req[3]);
    if (rid != 0x0001u) { /* 0x0001 = confirm running image as healthy */
        return nrc_reply(resp, max, 0x31u, NRC_REQUEST_OUT_OF_RANGE);
    }
    if (boot_confirm(s->store) != 0) {
        return nrc_reply(resp, max, 0x31u, NRC_GENERAL_PROGRAMMING_FAILURE);
    }
    resp[0] = 0x71u;
    resp[1] = 0x01u;
    resp[2] = req[2];
    resp[3] = req[3];
    return 4u;
}

/* ---- 0x3E ---- */
static uint16_t handle_tester_present(const uint8_t *req, uint16_t req_len,
                                      uint8_t *resp, uint16_t max)
{
    if (req_len < 2u) {
        return nrc_reply(resp, max, 0x3Eu, NRC_INCORRECT_LENGTH);
    }
    if ((uint8_t)(req[1] & 0x7Fu) != 0x00u) {
        return nrc_reply(resp, max, 0x3Eu, NRC_SUBFUNCTION_NOT_SUPPORTED);
    }
    if ((req[1] & 0x80u) != 0u) {
        return 0u;
    }
    resp[0] = 0x7Eu;
    resp[1] = 0x00u;
    return 2u;
}

void uds_init(uds_server_t *s, flash_port_t flash, metadata_store_t *store,
              const ota_port_t *port)
{
    memset(s, 0, sizeof *s);
    s->flash = flash;
    s->store = store;
    s->port = port;
    s->session = UDS_SESSION_DEFAULT;
    s->dl_next_counter = 1u;
}

uint16_t uds_handle(uds_server_t *s, const uint8_t *req, uint16_t req_len,
                    uint8_t *resp, uint16_t resp_max)
{
    uint8_t sid;

    if (s == 0 || req == 0 || req_len == 0u) {
        return 0u;
    }
    if (resp == 0 || resp_max < 3u) {
        return 0u;
    }

    sid = req[0];
    switch (sid) {
    case 0x10u:
        return handle_session(s, req, req_len, resp, resp_max);
    case 0x11u:
        return handle_ecu_reset(s, req, req_len, resp, resp_max);
    case 0x22u:
        return handle_read_data(s, req, req_len, resp, resp_max);
    case 0x27u:
        return handle_security(s, req, req_len, resp, resp_max);
    case 0x31u:
        return handle_routine(s, req, req_len, resp, resp_max);
    case 0x34u:
        return handle_request_download(s, req, req_len, resp, resp_max);
    case 0x36u:
        return handle_transfer_data(s, req, req_len, resp, resp_max);
    case 0x37u:
        return handle_transfer_exit(s, req, req_len, resp, resp_max);
    case 0x3Eu:
        return handle_tester_present(req, req_len, resp, resp_max);
    default:
        return nrc_reply(resp, resp_max, sid, NRC_SERVICE_NOT_SUPPORTED);
    }
}
