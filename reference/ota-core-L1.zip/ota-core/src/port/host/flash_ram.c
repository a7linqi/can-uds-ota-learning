#include "flash_ram.h"

#include <string.h>

void flash_ram_init(flash_ram_t *f)
{
    memset(f->mem, 0xFF, sizeof f->mem);
    f->write_fail_after = -1;
    f->write_ops = 0u;
    f->erase_ops = 0u;
}

static int ram_read(void *user, uint32_t offset, uint8_t *out, uint32_t len)
{
    flash_ram_t *f = (flash_ram_t *)user;

    if (f == 0 || out == 0) {
        return -1;
    }
    if (offset > FLASH_TOTAL_SIZE || len > FLASH_TOTAL_SIZE - offset) {
        return -1;
    }
    memcpy(out, &f->mem[offset], len);
    return 0;
}

static int ram_write(void *user, uint32_t offset, const uint8_t *data, uint32_t len)
{
    flash_ram_t *f = (flash_ram_t *)user;

    if (f == 0 || data == 0) {
        return -1;
    }
    if (offset > FLASH_TOTAL_SIZE || len > FLASH_TOTAL_SIZE - offset) {
        return -1;
    }
    f->write_ops++;
    if (f->write_fail_after >= 0 && f->write_ops > (uint32_t)f->write_fail_after) {
        return -1;
    }
    memcpy(&f->mem[offset], data, len);
    return 0;
}

static int ram_erase(void *user, uint32_t offset, uint32_t len)
{
    flash_ram_t *f = (flash_ram_t *)user;

    if (f == 0) {
        return -1;
    }
    if (offset > FLASH_TOTAL_SIZE || len > FLASH_TOTAL_SIZE - offset) {
        return -1;
    }
    f->erase_ops++;
    memset(&f->mem[offset], 0xFF, len);
    return 0;
}

flash_port_t flash_ram_port(flash_ram_t *f)
{
    flash_port_t p;

    p.erase = ram_erase;
    p.write = ram_write;
    p.read = ram_read;
    p.user = f;
    return p;
}
