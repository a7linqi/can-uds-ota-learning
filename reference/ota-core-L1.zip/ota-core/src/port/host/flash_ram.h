#ifndef FLASH_RAM_H
#define FLASH_RAM_H

#include "ota/flash_layout.h"
#include "ota/ota_port.h"

/* Host stand-in for the internal flash: 512 KiB of RAM that starts
   erased (0xFF). Also supports failure injection so tests can simulate
   a write that dies half way. */
typedef struct {
    uint8_t  mem[FLASH_TOTAL_SIZE];
    int      write_fail_after;  /* -1 = never fail                */
    uint32_t write_ops;
    uint32_t erase_ops;
} flash_ram_t;

void flash_ram_init(flash_ram_t *f);
flash_port_t flash_ram_port(flash_ram_t *f);

#endif /* FLASH_RAM_H */
